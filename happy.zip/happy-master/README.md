<h1 align="center">
  <img src=".github/Logo.png" alt="happy" title="happy" />
</h1>



Projeto sendo criado no NLW 3 :rocket:
